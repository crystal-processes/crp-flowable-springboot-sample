{
  "key": "acme",
  "name": "ACME",
  "description": "Sample application to demonstrate flowable and flowable-ex.",
  "theme": "theme-1",
  "icon": "glyphicon-asterisk",
  "usersAccess": null,
  "groupsAccess": null,
  "flowApp": false,
  "url": null,
  "paletteDefinitionCategory": "work",
  "extension": {
    "design": {
      "childModels": [
        {
          "key": "A001-migration",
          "type": "bpmn"
        },
        {
          "key": "P030-processInsuranceEvent",
          "type": "bpmn"
        },
        {
          "key": "P004-jpaServiceProcessInsuranceEvent",
          "type": "bpmn"
        },
        {
          "key": "P003-jpaProcessInsuranceEvent",
          "type": "bpmn"
        },
        {
          "key": "P002-processInsuranceEvent",
          "type": "bpmn"
        },
        {
          "key": "P001-helloWorld",
          "type": "bpmn"
        }
      ]
    }
  }
}
